PWA Kiểm Kê Hàng Hóa - GitHub Pages ready.
