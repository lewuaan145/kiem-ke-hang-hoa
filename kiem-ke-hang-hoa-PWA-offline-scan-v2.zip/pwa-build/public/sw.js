const CACHE='kiem-ke-v4';
const LOCAL=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./src/main.jsx','./src/App.jsx','./src/style.css'];
const REMOTE=[
  'https://cdn.tailwindcss.com',
  'https://unpkg.com/@babel/standalone/babel.min.js',
  'https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js',
  'https://esm.sh/react@18.3.1',
  'https://esm.sh/react-dom@18.3.1/client',
  'https://esm.sh/xlsx@0.18.5',
  'https://esm.sh/lucide-react@0.468.0'
];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(async c=>{
  await Promise.all([...LOCAL,...REMOTE].map(x=>c.add(x).catch(()=>{})));
  await self.skipWaiting();
})));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET') return;
  e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request).then(res=>{
    const copy=res.clone();
    caches.open(CACHE).then(c=>c.put(e.request,copy)).catch(()=>{});
    return res;
  }).catch(()=>caches.match('./index.html'))));
});
