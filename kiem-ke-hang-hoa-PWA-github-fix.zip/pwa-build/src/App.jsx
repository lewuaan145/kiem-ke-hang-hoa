import React, { useState, useEffect, useMemo, useRef, useDeferredValue } from "react";
import * as XLSX from "xlsx";
import {
  Upload,
  Search,
  Plus,
  Minus,
  Check,
  X,
  FileSpreadsheet,
  RotateCcw,
  StickyNote,
  Download,
  ListChecks,
  Lock,
  AlertTriangle,
  ArrowLeft,
  ChevronRight,
  ChevronLeft,
  Layers,
} from "lucide-react";

// ---------- helpers ----------
function normalize(s) {
  return (s ?? "")
    .toString()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .trim();
}

function normalizeTight(s) {
  return normalize(s).replace(/\s+/g, "");
}

const FIELD_DEFS = [
  { key: "category", label: "Ngành hàng cấp 1", required: false, guesses: ["nganhhangcap1", "nganhhang", "nganh", "category", "department", "nhomhang", "nhomhangcap1"] },
  { key: "sku", label: "Mã sản phẩm", required: true, guesses: ["masp", "masanpham", "sku", "code"] },
  { key: "name", label: "Tên sản phẩm", required: true, guesses: ["tensanpham", "tensp", "tenhang", "name"] },
  { key: "unit", label: "Đơn vị tính", required: false, guesses: ["dvt", "donvitinh", "unit"] },
  {
    key: "systemQty",
    label: "Tồn hệ thống",
    required: true,
    guesses: ["tonkho", "soluongthuc", "soluong", "ton", "sl", "qty", "stock"],
  },
];

const STOP_WORDS = new Set(["cho", "loai", "hang", "san", "pham", "chiec", "cai"]);

function getStatus(item) {
  if (!item.touched) return { label: "Chưa kiểm", tone: "neutral" };
  const diff = item.actualQty - item.systemQty;
  if (diff === 0) return { label: "Khớp", tone: "match" };
  if (diff < 0) return { label: `Thiếu ${Math.abs(diff)}`, tone: "short" };
  return { label: `Thừa ${diff}`, tone: "surplus" };
}

const TONE_STYLE = {
  neutral: "bg-stone-100 text-stone-500 border-stone-200",
  match: "bg-emerald-50 text-emerald-700 border-emerald-300",
  short: "bg-red-50 text-red-700 border-red-300",
  surplus: "bg-amber-50 text-amber-700 border-amber-300",
};

export default function App() {
  const [stage, setStage] = useState("upload"); // upload | mapping | counting
  const [fileName, setFileName] = useState("");
  const [workbook, setWorkbook] = useState(null);
  const [sheetNames, setSheetNames] = useState([]);
  const [selectedSheet, setSelectedSheet] = useState("");
  const [rawRows, setRawRows] = useState([]);
  const [headerRowIdx, setHeaderRowIdx] = useState(0);
  const [colMap, setColMap] = useState({});
  const [items, setItems] = useState([]);
  const [category, setCategory] = useState("");
  const [completedCategories, setCompletedCategories] = useState(new Set());
  const [query, setQuery] = useState("");
  const [scannerOpen, setScannerOpen] = useState(false);
  const scannerRef = useRef(null);
  const scannerInstanceRef = useRef(null);
  const deferredQuery = useDeferredValue(query);
  const [filter, setFilter] = useState("all");
  const [finalized, setFinalized] = useState(false);
  const [finalizedAt, setFinalizedAt] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [expandedNotes, setExpandedNotes] = useState(new Set());
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef(null);

  // ---- read sheet into rawRows whenever workbook/sheet changes ----
  useEffect(() => {
    if (!workbook || !selectedSheet) return;
    const rows = XLSX.utils.sheet_to_json(workbook.Sheets[selectedSheet], {
      header: 1,
      defval: "",
    });
    setRawRows(rows);
    let bestIdx = 0,
      bestCount = -1;
    for (let i = 0; i < Math.min(10, rows.length); i++) {
      const count = rows[i].filter((c) => String(c).trim() !== "").length;
      if (count > bestCount) {
        bestCount = count;
        bestIdx = i;
      }
    }
    setHeaderRowIdx(bestIdx);
    setStage("mapping");
  }, [workbook, selectedSheet]);

  // ---- guess column mapping whenever header row changes ----
  useEffect(() => {
    if (!rawRows.length) return;
    const headerCells = rawRows[headerRowIdx] || [];
    const guessed = {};
    FIELD_DEFS.forEach((f) => {
      const idx = headerCells.findIndex((cell) => {
        const n = normalize(cell);
        return n && f.guesses.some((g) => n.includes(g));
      });
      if (idx !== -1) guessed[f.key] = idx;
    });
    setColMap(guessed);
  }, [rawRows, headerRowIdx]);

  function handleFile(file) {
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target.result);
        const wb = XLSX.read(data, { type: "array" });
        setWorkbook(wb);
        setSheetNames(wb.SheetNames);
        setSelectedSheet(wb.SheetNames[0]);
      } catch (err) {
        alert("Không đọc được tệp. Vui lòng chọn đúng tệp Excel (.xlsx, .xls, .csv).");
      }
    };
    reader.readAsArrayBuffer(file);
  }

  function onDrop(e) {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  }

  function startCounting() {
    const dataRows = rawRows.slice(headerRowIdx + 1);
    const built = dataRows
      .map((row, idx) => {
        const sku = String(row[colMap.sku] ?? "").trim();
        const name = String(row[colMap.name] ?? "").trim();
        if (!sku && !name) return null;
        const unit =
          colMap.unit !== undefined && colMap.unit !== "" ? String(row[colMap.unit] ?? "").trim() : "";
        const qtyRaw = row[colMap.systemQty];
        const systemQty = Math.max(0, Math.round(parseFloat(qtyRaw) || 0));
        return {
          id: `${idx}-${sku || name}`,
          sku,
          name,
          unit,
          category: colMap.category !== undefined && colMap.category !== "" ? String(row[colMap.category] ?? "").trim() : "Chưa phân loại",
          systemQty,
          actualQty: 0,
          touched: false,
          note: "",
        };
      })
      .filter(Boolean);
    if (!built.length) {
      alert("Không tìm thấy dòng dữ liệu hợp lệ. Kiểm tra lại dòng tiêu đề và cột đã chọn.");
      return;
    }
    setItems(built);
    const cats = [...new Set(built.map((it) => it.category || "Chưa phân loại"))];
    setCategory(cats[0] || "Chưa phân loại");
    setCompletedCategories(new Set());
    setQuery("");
    setFilter("all");
    setStage("counting");
  }

  function adjustQty(id, delta) {
    if (finalized) return;
    const target = items.find((it) => it.id === id);
    if (target && completedCategories.has(target.category || "Chưa phân loại")) return;
    setItems((prev) =>
      prev.map((it) => (it.id === id ? { ...it, actualQty: Math.max(0, it.actualQty + delta), touched: true } : it))
    );
  }
  function setQtyDirect(id, val) {
    if (finalized) return;
    const target = items.find((it) => it.id === id);
    if (target && completedCategories.has(target.category || "Chưa phân loại")) return;
    const n = Math.max(0, parseInt(val, 10) || 0);
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, actualQty: n, touched: true } : it)));
  }
  function matchQuick(id) {
    if (finalized) return;
    const target = items.find((it) => it.id === id);
    if (target && completedCategories.has(target.category || "Chưa phân loại")) return;
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, actualQty: it.systemQty, touched: true } : it)));
  }
  function resetQty(id) {
    if (finalized) return;
    const target = items.find((it) => it.id === id);
    if (target && completedCategories.has(target.category || "Chưa phân loại")) return;
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, actualQty: 0, touched: false } : it)));
  }
  function setNote(id, note) {
    const target = items.find((it) => it.id === id);
    if (target && completedCategories.has(target.category || "Chưa phân loại")) return;
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, note } : it)));
  }
  function toggleNote(id) {
    setExpandedNotes((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  const keywordChips = useMemo(() => {
    const freq = new Map();
    items.forEach((it) => {
      it.name.split(/\s+/).forEach((raw) => {
        const w = raw.trim();
        if (w.length < 3) return;
        const n = normalize(w);
        if (!n || STOP_WORDS.has(n)) return;
        const cur = freq.get(n);
        if (cur) cur.count++;
        else freq.set(n, { count: 1, display: w });
      });
    });
    return [...freq.entries()]
      .filter(([, v]) => v.count >= 2)
      .sort((a, b) => b[1].count - a[1].count)
      .slice(0, 14)
      .map(([token, v]) => ({ token, display: v.display }));
  }, [items]);

  function toggleChip(chip) {
    const words = query.trim().split(/\s+/).filter(Boolean);
    const isActive = words.some((w) => normalize(w) === chip.token);
    if (isActive) {
      setQuery(words.filter((w) => normalize(w) !== chip.token).join(" "));
    } else {
      setQuery([...words, chip.display].join(" "));
    }
  }

  const categories = useMemo(() => {
    const map = new Map();
    items.forEach((it) => {
      const name = it.category || "Chưa phân loại";
      if (!map.has(name)) map.set(name, { name, total: 0, counted: 0 });
      const c = map.get(name);
      c.total++;
      if (it.touched) c.counted++;
    });
    return [...map.values()].sort((a, b) => a.name.localeCompare(b.name, "vi"));
  }, [items]);

  const currentCategory = categories.find((c) => c.name === category) || categories[0];
  const categoryIndex = Math.max(0, categories.findIndex((c) => c.name === category));

  const filteredItems = useMemo(() => {
    const tokens = deferredQuery.trim().split(/\s+/).filter(Boolean).map(normalize);
    return items.filter((it) => {
      if (category && (it.category || "Chưa phân loại") !== category) return false;
      if (tokens.length) {
        const hay = normalize(`${it.sku} ${it.name} ${it.unit}`);
        if (!tokens.every((t) => hay.includes(t))) return false;
      }
      const status = getStatus(it);
      if (filter === "uncounted" && it.touched) return false;
      if (filter === "matched" && status.tone !== "match") return false;
      if (filter === "variance" && !(status.tone === "short" || status.tone === "surplus")) return false;
      return true;
    });
  }, [items, deferredQuery, filter, category]);

  const displayItems = filteredItems.slice(0, 200);

  const summary = useMemo(() => {
    let counted = 0,
      matched = 0,
      short = 0,
      surplus = 0,
      varianceQty = 0;
    items.forEach((it) => {
      if (it.touched) {
        counted++;
        const diff = it.actualQty - it.systemQty;
        if (diff === 0) matched++;
        else if (diff < 0) short++;
        else surplus++;
        varianceQty += Math.abs(diff);
      }
    });
    return {
      total: items.length,
      counted,
      uncounted: items.length - counted,
      matched,
      short,
      surplus,
      varianceQty,
    };
  }, [items]);

  async function finalizeCount() {
    if (!currentCategory) return;
    if (currentCategory.counted < currentCategory.total) {
      alert(`Ngành “${currentCategory.name}” còn ${currentCategory.total - currentCategory.counted} sản phẩm chưa kiểm. Hãy kiểm đủ trước khi chốt ngành.`);
      return;
    }
    const next = new Set(completedCategories);
    next.add(currentCategory.name);
    setCompletedCategories(next);
    setConfirmOpen(false);
    const nextUncompleted = categories.find((c) => !next.has(c.name));
    if (nextUncompleted) {
      setCategory(nextUncompleted.name);
      setQuery("");
      setFilter("all");
    }
  }

  async function openScanner() {
    if (!window.Html5Qrcode) {
      alert("Chức năng quét mã chưa tải xong. Hãy mở ứng dụng khi có mạng một lần rồi thử lại.");
      return;
    }
    setScannerOpen(true);
    setTimeout(async () => {
      try {
        const scanner = new window.Html5Qrcode("barcode-reader");
        scannerInstanceRef.current = scanner;
        await scanner.start(
          { facingMode: "environment" },
          { fps: 12, qrbox: { width: 280, height: 160 }, aspectRatio: 1.777 },
          async (decodedText) => {
            const code = String(decodedText).trim();
            const exact = items.find((it) => normalize(it.sku) === normalize(code) && (it.category || "Chưa phân loại") === category);
            setQuery(code);
            try { await scanner.stop(); } catch {}
            try { scanner.clear(); } catch {}
            scannerInstanceRef.current = null;
            setScannerOpen(false);
            if (!exact) {
              setTimeout(() => alert(`Không tìm thấy mã “${code}” trong ngành “${category}”.`), 50);
            }
          },
          () => {}
        );
      } catch (err) {
        scannerInstanceRef.current = null;
        setScannerOpen(false);
        alert("Không mở được camera. Hãy cấp quyền Camera cho Safari/PWA rồi thử lại.");
      }
    }, 80);
  }

  async function closeScanner() {
    const scanner = scannerInstanceRef.current;
    if (scanner) {
      try { await scanner.stop(); } catch {}
      try { scanner.clear(); } catch {}
      scannerInstanceRef.current = null;
    }
    setScannerOpen(false);
  }

  function goCategory(delta) {
    if (!categories.length) return;
    const nextIndex = Math.min(categories.length - 1, Math.max(0, categoryIndex + delta));
    setCategory(categories[nextIndex].name);
    setQuery("");
    setFilter("all");
  }

  function finishAllCategories() {
    setFinalized(true);
    setFinalizedAt(new Date().toLocaleString("vi-VN"));
    setConfirmOpen(false);
  }

  function resetSession() {
    setStage("upload");
    setFileName("");
    setWorkbook(null);
    setSheetNames([]);
    setSelectedSheet("");
    setRawRows([]);
    setHeaderRowIdx(0);
    setColMap({});
    setItems([]);
    setCategory("");
    setCompletedCategories(new Set());
    setQuery("");
    setFilter("all");
    setFinalized(false);
    setFinalizedAt(null);
    setExpandedNotes(new Set());
  }

  function handleExport() {
    const headerRow = ["Ngành hàng cấp 1", "Mã SP", "Tên SP", "ĐVT", "Tồn hệ thống", "Thực tế kiểm", "Chênh lệch", "Trạng thái", "Ghi chú"];
    const dataRows = items.map((it) => {
      const status = getStatus(it);
      const diff = it.actualQty - it.systemQty;
      return [
        it.category || "Chưa phân loại",
        it.sku,
        it.name,
        it.unit,
        it.systemQty,
        it.touched ? it.actualQty : "",
        it.touched ? diff : "",
        status.label,
        it.note,
      ];
    });
    const wsDetail = XLSX.utils.aoa_to_sheet([headerRow, ...dataRows]);
    wsDetail["!cols"] = [{ wch: 14 }, { wch: 34 }, { wch: 8 }, { wch: 12 }, { wch: 12 }, { wch: 10 }, { wch: 12 }, { wch: 24 }];

    const summaryRows = [
      ["BÁO CÁO KIỂM KÊ HÀNG HOÁ"],
      ["Tệp gốc", fileName],
      ["Trạng thái", finalized ? `Đã chốt kiểm lúc ${finalizedAt}` : "Bản nháp — chưa chốt kiểm"],
      [],
      ["Tổng số SP", summary.total],
      ["Số ngành hàng cấp 1", categories.length],
      ["Ngành đã hoàn tất", completedCategories.size],
      ["Đã kiểm", summary.counted],
      ["Chưa kiểm", summary.uncounted],
      ["Khớp", summary.matched],
      ["Thiếu (số SP)", summary.short],
      ["Thừa (số SP)", summary.surplus],
      ["Tổng chênh lệch số lượng", summary.varianceQty],
    ];
    const wsSummary = XLSX.utils.aoa_to_sheet(summaryRows);
    wsSummary["!cols"] = [{ wch: 26 }, { wch: 30 }];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, wsSummary, "Tong hop");
    XLSX.utils.book_append_sheet(wb, wsDetail, "Chi tiet kiem ke");
    const base = fileName.replace(/\.[^.]+$/, "") || "tonkho";
    const fname = `KiemKe_${base}_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(wb, fname);
  }

  // ================= RENDER =================
  return (
    <div className="min-h-screen bg-stone-50 text-slate-900 font-sans">
      {stage === "upload" && <UploadStage />}
      {stage === "mapping" && <MappingStage />}
      {stage === "counting" && <CountingStage />}
    </div>
  );

  // ---------- Stage: Upload ----------
  function UploadStage() {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-xl">
          <div className="flex items-center gap-2 mb-6 justify-center">
            <ListChecks className="w-7 h-7 text-slate-900" />
            <h1 className="text-2xl font-bold tracking-tight">Kiểm Kê Hàng Hoá</h1>
          </div>
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={onDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`cursor-pointer rounded-lg border-2 border-dashed p-12 text-center transition-colors ${
              dragOver ? "border-slate-900 bg-stone-100" : "border-stone-300 bg-white"
            }`}
          >
            <Upload className="w-10 h-10 mx-auto mb-4 text-stone-400" />
            <p className="font-medium text-slate-800">Kéo thả tệp Excel tồn kho vào đây</p>
            <p className="text-sm text-stone-500 mt-1">hoặc bấm để chọn tệp (.xlsx, .xls, .csv)</p>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFile(file);
              }}
            />
          </div>
          <p className="text-xs text-stone-400 mt-4 text-center">
            Ứng dụng đọc tệp ngay trên trình duyệt — dữ liệu không được tải lên máy chủ nào khác.
          </p>
        </div>
      </div>
    );
  }

  // ---------- Stage: Mapping ----------
  function MappingStage() {
    const headerCells = rawRows[headerRowIdx] || [];
    const previewRows = rawRows.slice(headerRowIdx + 1, headerRowIdx + 6);
    const canStart = colMap.sku !== undefined && colMap.name !== undefined && colMap.systemQty !== undefined;
    const rowChoices = rawRows.slice(0, Math.min(15, rawRows.length));

    return (
      <div className="max-w-4xl mx-auto p-6">
        <button onClick={resetSession} className="flex items-center gap-1 text-sm text-stone-500 hover:text-slate-900 mb-4">
          <ArrowLeft className="w-4 h-4" /> Chọn tệp khác
        </button>
        <div className="flex items-center gap-2 mb-1">
          <FileSpreadsheet className="w-5 h-5 text-slate-700" />
          <h2 className="text-lg font-bold">{fileName}</h2>
        </div>
        <p className="text-sm text-stone-500 mb-6">Xác nhận cột dữ liệu trước khi bắt đầu kiểm kê.</p>

        {sheetNames.length > 1 && (
          <div className="mb-4">
            <label className="block text-xs font-semibold text-stone-500 mb-1">SHEET</label>
            <select
              value={selectedSheet}
              onChange={(e) => setSelectedSheet(e.target.value)}
              className="border border-stone-300 rounded px-3 py-2 text-sm bg-white"
            >
              {sheetNames.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="mb-6">
          <label className="block text-xs font-semibold text-stone-500 mb-1">DÒNG TIÊU ĐỀ</label>
          <select
            value={headerRowIdx}
            onChange={(e) => setHeaderRowIdx(parseInt(e.target.value, 10))}
            className="w-full border border-stone-300 rounded px-3 py-2 text-sm bg-white font-mono"
          >
            {rowChoices.map((row, i) => (
              <option key={i} value={i}>
                Dòng {i + 1}: {row.slice(0, 6).join(" | ").slice(0, 80)}
              </option>
            ))}
          </select>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 mb-6">
          {FIELD_DEFS.map((f) => (
            <div key={f.key}>
              <label className="block text-xs font-semibold text-stone-500 mb-1">
                {f.label.toUpperCase()} {f.required && <span className="text-red-500">*</span>}
              </label>
              <select
                value={colMap[f.key] ?? ""}
                onChange={(e) =>
                  setColMap((prev) => ({
                    ...prev,
                    [f.key]: e.target.value === "" ? undefined : parseInt(e.target.value, 10),
                  }))
                }
                className="w-full border border-stone-300 rounded px-3 py-2 text-sm bg-white"
              >
                <option value="">{f.required ? "— Chọn cột —" : "— Không dùng —"}</option>
                {headerCells.map((cell, idx) => (
                  <option key={idx} value={idx}>
                    {String(cell).trim() || `(Cột ${idx + 1})`}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>

        {previewRows.length > 0 && (
          <div className="mb-6 overflow-x-auto border border-stone-200 rounded-lg bg-white">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-stone-100 text-stone-500">
                  {headerCells.map((c, i) => (
                    <th key={i} className="px-3 py-2 text-left font-semibold whitespace-nowrap">
                      {String(c).trim() || `Cột ${i + 1}`}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {previewRows.map((row, ri) => (
                  <tr key={ri} className="border-t border-stone-100">
                    {headerCells.map((_, ci) => (
                      <td key={ci} className="px-3 py-2 whitespace-nowrap text-stone-700">
                        {String(row[ci] ?? "")}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <button
          onClick={startCounting}
          disabled={!canStart}
          className="w-full sm:w-auto px-6 py-3 rounded-lg bg-slate-900 text-white font-semibold disabled:bg-stone-300 disabled:cursor-not-allowed hover:bg-slate-800 transition-colors"
        >
          Bắt đầu kiểm kê →
        </button>
        {!canStart && <p className="text-xs text-red-500 mt-2">Chọn đủ Mã sản phẩm, Tên sản phẩm và Tồn hệ thống.</p>}
      </div>
    );
  }

  // ---------- Stage: Counting ----------
  function CountingStage() {
    const stats = [
      { label: "Tổng SP", value: summary.total },
      { label: "Đã kiểm", value: summary.counted },
      { label: "Khớp", value: summary.matched },
      { label: "Lệch", value: summary.short + summary.surplus },
    ];
    const tabs = [
      { key: "all", label: "Tất cả" },
      { key: "uncounted", label: `Chưa kiểm (${summary.uncounted})` },
      { key: "matched", label: `Khớp (${summary.matched})` },
      { key: "variance", label: `Lệch (${summary.short + summary.surplus})` },
    ];

    return (
      <div className="pb-10">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-slate-900 text-white">
          <div className="max-w-5xl mx-auto px-4 py-3">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-2 relative">
                <ListChecks className="w-5 h-5" />
                <div>
                  <div className="font-bold leading-tight">Kiểm Kê Hàng Hoá</div>
                  <div className="text-xs text-slate-400 leading-tight truncate max-w-[200px]">{fileName}</div>
                  <div className="text-[10px] text-emerald-300">● PWA offline</div>
                </div>
                {finalized && (
                  <div className="absolute -right-16 -top-3 -rotate-12 border-2 border-red-500 text-red-500 rounded-full px-2 py-0.5 text-[10px] font-bold tracking-wider bg-slate-900/80">
                    ĐÃ CHỐT
                  </div>
                )}
              </div>
              <div className="flex gap-2">
                {!finalized ? (
                  completedCategories.size === categories.length && categories.length > 0 ? (
                    <button onClick={finishAllCategories} className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-500">
                      <Lock className="w-4 h-4" /> Hoàn tất kiểm kê
                    </button>
                  ) : currentCategory && completedCategories.has(currentCategory.name) ? (
                    <span className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 text-slate-300 text-sm">
                      <Check className="w-4 h-4" /> Đã chốt ngành
                    </span>
                  ) : (
                    <button
                      onClick={() => setConfirmOpen(true)}
                      disabled={!currentCategory || currentCategory.counted < currentCategory.total}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-amber-500 text-slate-900 text-sm font-semibold hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <Lock className="w-4 h-4" /> Chốt ngành
                    </button>
                  )
                ) : (
                  <span className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 text-slate-300 text-sm">
                    <Lock className="w-4 h-4" /> Đã hoàn tất {finalizedAt}
                  </span>
                )}
                <button
                  onClick={handleExport}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-500"
                >
                  <Download className="w-4 h-4" /> Xuất Excel
                </button>
                <button
                  onClick={resetSession}
                  title="Bắt đầu phiên kiểm mới"
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-700 text-white text-sm hover:bg-slate-600"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="flex gap-4 mt-3 font-mono text-sm">
              {stats.map((s) => (
                <div key={s.label} className="flex items-baseline gap-1">
                  <span className="text-slate-400 text-xs">{s.label}</span>
                  <span className="font-bold">{s.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Category workflow */}
        <div className="max-w-5xl mx-auto px-4 pt-4">
          <div className="rounded-xl border border-stone-200 bg-white p-3">
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-[10px] font-semibold text-stone-400 uppercase tracking-wide">Ngành hàng cấp 1</div>
                <div className="flex items-center gap-2 mt-1">
                  <Layers className="w-4 h-4 text-slate-600 shrink-0" />
                  <select
                    value={category}
                    onChange={(e) => { setCategory(e.target.value); setQuery(""); setFilter("all"); }}
                    className="min-w-0 flex-1 border-0 bg-transparent font-bold text-sm focus:outline-none"
                  >
                    {categories.map((c, i) => {
                      const allowed = i === 0 || categories.slice(0, i).every((prev) => completedCategories.has(prev.name));
                      return (
                        <option key={c.name} value={c.name} disabled={!allowed}>
                          {c.name} — {c.counted}/{c.total} đã kiểm{completedCategories.has(c.name) ? " ✓" : ""}
                        </option>
                      );
                    })}
                  </select>
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-xs font-semibold text-slate-700">{categoryIndex + 1}/{categories.length}</div>
                <div className="text-[10px] text-stone-400">ngành</div>
              </div>
            </div>
            <div className="mt-3 h-1.5 rounded-full bg-stone-100 overflow-hidden">
              <div className="h-full bg-slate-900 transition-all" style={{ width: `${categories.length ? (completedCategories.size / categories.length) * 100 : 0}%` }} />
            </div>
            <div className="flex justify-between items-center mt-2">
              <button onClick={() => goCategory(-1)} disabled={categoryIndex <= 0} className="flex items-center gap-1 text-xs px-2 py-1 rounded border border-stone-200 disabled:opacity-30"><ChevronLeft className="w-3.5 h-3.5" /> Ngành trước</button>
              <span className="text-xs text-stone-500">{currentCategory ? `${currentCategory.counted}/${currentCategory.total} sản phẩm` : ""}</span>
              <button onClick={() => goCategory(1)} disabled={categoryIndex >= categories.length - 1 || !completedCategories.has(currentCategory?.name)} className="flex items-center gap-1 text-xs px-2 py-1 rounded border border-stone-200 disabled:opacity-30">Ngành tiếp <ChevronRight className="w-3.5 h-3.5" /></button>
            </div>
          </div>
        </div>

        {/* Search + chips */}
        <div className="max-w-5xl mx-auto px-4 pt-4">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Gõ để tìm theo mã hoặc tên sản phẩm..."
              className="w-full pl-9 pr-9 py-2.5 rounded-lg border border-stone-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
            {query ? (
              <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-slate-900">
                <X className="w-4 h-4" />
              </button>
            ) : (
              <button onClick={openScanner} title="Quét mã sản phẩm" className="absolute right-2 top-1/2 -translate-y-1/2 px-2 py-1 rounded-md bg-slate-900 text-white text-xs font-semibold">Quét mã</button>
            )}
          </div>

          {keywordChips.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-2">
              {keywordChips.map((chip) => {
                const active = query.trim().split(/\s+/).filter(Boolean).some((w) => normalize(w) === chip.token);
                return (
                  <button
                    key={chip.token}
                    onClick={() => toggleChip(chip)}
                    className={`px-2.5 py-1 rounded-full text-xs border transition-colors ${
                      active
                        ? "bg-slate-900 text-white border-slate-900"
                        : "bg-white text-stone-600 border-stone-300 hover:border-slate-900"
                    }`}
                  >
                    {chip.display}
                  </button>
                );
              })}
            </div>
          )}

          <div className="flex gap-1.5 mt-3">
            {tabs.map((t) => (
              <button
                key={t.key}
                onClick={() => setFilter(t.key)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium border ${
                  filter === t.key ? "bg-slate-900 text-white border-slate-900" : "bg-white text-stone-500 border-stone-300"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Item list */}
        <div className="max-w-5xl mx-auto px-4 mt-4 space-y-2">
          {filteredItems.length === 0 && (
            <div className="text-center text-stone-400 py-16 text-sm">Không tìm thấy sản phẩm phù hợp.</div>
          )}
          {displayItems.map((it) => {
            const status = getStatus(it);
            const noteOpen = expandedNotes.has(it.id);
            return (
              <div key={it.id} className="bg-white border border-stone-200 rounded-lg p-3">
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs text-stone-500 bg-stone-100 rounded px-1.5 py-0.5">{it.sku || "—"}</span>
                      {it.unit && <span className="text-xs text-stone-400">{it.unit}</span>}
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${TONE_STYLE[status.tone]}`}>
                        {status.label}
                      </span>
                    </div>
                    <div className="font-medium text-sm mt-0.5 truncate">{it.name || "(không tên)"}</div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-center">
                      <div className="text-[10px] text-stone-400 uppercase">Hệ thống</div>
                      <div className="font-mono font-bold text-sm">{it.systemQty}</div>
                    </div>

                    <div className="flex items-center border border-stone-300 rounded-lg overflow-hidden">
                      <button
                        onClick={() => adjustQty(it.id, -1)}
                        disabled={finalized || completedCategories.has(it.category || "Chưa phân loại")}
                        className="px-2 py-1.5 text-stone-600 hover:bg-stone-100 disabled:opacity-40"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <input
                        type="number"
                        value={it.actualQty}
                        disabled={finalized || completedCategories.has(it.category || "Chưa phân loại")}
                        onChange={(e) => setQtyDirect(it.id, e.target.value)}
                        className="w-12 text-center font-mono font-bold text-sm border-x border-stone-300 py-1.5 focus:outline-none disabled:bg-stone-50"
                      />
                      <button
                        onClick={() => adjustQty(it.id, 1)}
                        disabled={finalized || completedCategories.has(it.category || "Chưa phân loại")}
                        className="px-2 py-1.5 text-stone-600 hover:bg-stone-100 disabled:opacity-40"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <button
                      onClick={() => matchQuick(it.id)}
                      disabled={finalized}
                      title="Đặt bằng tồn hệ thống"
                      className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 disabled:opacity-40"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => resetQty(it.id)}
                      disabled={finalized}
                      title="Xoá số đã đếm"
                      className="p-1.5 rounded-lg text-stone-400 hover:bg-stone-100 disabled:opacity-40"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => toggleNote(it.id)}
                      title="Ghi chú"
                      className={`p-1.5 rounded-lg hover:bg-stone-100 ${it.note ? "text-amber-500" : "text-stone-400"}`}
                    >
                      <StickyNote className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {noteOpen && (
                  <input
                    value={it.note}
                    disabled={finalized || completedCategories.has(it.category || "Chưa phân loại")}
                    onChange={(e) => setNote(it.id, e.target.value)}
                    placeholder="Ghi chú (vd: hàng lỗi, để nơi khác...)"
                    className="mt-2 w-full text-xs border border-stone-200 rounded px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-slate-900 disabled:bg-stone-50"
                  />
                )}
              </div>
            );
          })}
        </div>

        {/* Barcode scanner */}
        {scannerOpen && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-40">
            <div className="bg-white rounded-2xl p-4 w-full max-w-md">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="font-bold">Quét mã sản phẩm</h3>
                  <p className="text-xs text-stone-500">Đưa mã vạch vào khung quét</p>
                </div>
                <button onClick={closeScanner} className="p-2 rounded-lg hover:bg-stone-100"><X className="w-5 h-5" /></button>
              </div>
              <div id="barcode-reader" ref={scannerRef} className="overflow-hidden rounded-xl bg-black min-h-[260px]" />
              <button onClick={closeScanner} className="w-full mt-3 px-4 py-2.5 rounded-lg border border-stone-300 font-medium">Đóng camera</button>
            </div>
          </div>
        )}

        {/* Confirm modal */}
        {confirmOpen && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-30">
            <div className="bg-white rounded-xl p-6 max-w-sm w-full">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold">Chốt kiểm kê?</h3>
              </div>
              <p className="text-sm text-stone-600 mb-1">
                Sau khi chốt, số lượng đếm sẽ bị khoá và không thể chỉnh sửa thêm.
              </p>
              {summary.uncounted > 0 && (
                <p className="text-sm text-red-600 font-medium mb-3">
                  Còn {summary.uncounted} sản phẩm chưa kiểm.
                </p>
              )}
              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => setConfirmOpen(false)}
                  className="flex-1 px-4 py-2 rounded-lg border border-stone-300 text-sm font-medium hover:bg-stone-50"
                >
                  Huỷ
                </button>
                <button
                  onClick={finalizeCount}
                  className="flex-1 px-4 py-2 rounded-lg bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800"
                >
                  Xác nhận chốt
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}
