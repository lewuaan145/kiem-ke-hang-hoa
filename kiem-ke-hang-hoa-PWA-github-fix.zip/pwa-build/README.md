# Kiểm Kê Hàng Hóa – PWA offline + scan mã

## Có gì trong bản này
- Import Excel (.xlsx/.xls/.csv)
- Kiểm theo từng ngành hàng cấp 1 theo thứ tự
- Chỉ được chuyển sang ngành tiếp theo sau khi chốt ngành hiện tại
- Quét mã vạch bằng camera iPhone
- Tìm theo mã/tên sản phẩm
- Nhập thực tế, khớp nhanh, ghi chú
- Chốt từng ngành và hoàn tất toàn bộ phiên
- Xuất Excel có cột Ngành hàng cấp 1
- Service Worker cache app và các thư viện sau lần mở online đầu tiên để hỗ trợ offline

## Cài trên iPhone
1. Đưa thư mục `pwa-build` lên hosting HTTPS.
2. Mở URL bằng Safari.
3. Mở app ít nhất 1 lần khi có mạng để cache toàn bộ tài nguyên.
4. Safari > Chia sẻ > Thêm vào Màn hình chính.
5. Từ lần sau có thể sử dụng khi mất mạng, tùy chính sách lưu trữ của iOS.

## Lưu ý camera
Camera trong PWA trên iOS có thể có lỗi theo từng phiên bản WebKit. Nếu camera bị đen/đơ trong app Home Screen, mở cùng URL trực tiếp bằng Safari để scan; iOS đã từng có các lỗi camera trong PWA được WebKit ghi nhận.
